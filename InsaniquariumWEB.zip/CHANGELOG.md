## Update 1.2.0

- 1 new fish
- 3 new aliens
- 3 new trash items
- Nerfed ultravore and alien sell value

## Update 1.1.0

- Fixed all fish and alien sprites to be 256x256