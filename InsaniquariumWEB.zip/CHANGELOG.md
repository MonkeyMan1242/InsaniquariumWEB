## Update 1.4.1

- Fixed new fish from 1.4.0

## Update 1.4.0

- 2 new **animated** fish

## Update 1.3.0

**Fixes to basically every sprite in the entire mod!**
- Re-rendered every sprite to be closer to their original images
- No more blurry textures! (It was literally one setting in Godot)
- Rocky's bottom fin is no longer transparent

**Other changes:**
- Small Guppy renamed to Guppy Jr.
- Large Guppy renamed to Guppy
- Medium Guppy removed! (Felt too redundant. Replaced with...)
- 1 new fish (Star Guppy)
- Psychosquid split into two fish (Red and blue variants to represent his active and inactive forms)
- Nerfed all fish and alien sell values

## Update 1.2.0

- 1 new fish
- 3 new aliens
- 3 new trash items
- Nerfed ultravore and alien sell values

## Update 1.1.0

- Edited all fish and alien sprites to be 256 x 256