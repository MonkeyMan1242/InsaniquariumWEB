## InsaniquariumWEB

![Large Guppy](https://i.imgur.com/hT1mjQV.png)

Adds 20+ Insaniquarium fish and aliens to WEBFISHING! All fish are found in lakes and rivers, and all aliens in the ocean.

You can also find this mod at it's [GitHub](https://github.com/MonkeyMan1242/InsaniquariumWEB).

<details>
<summary>List of fish</summary>

| Name | Rarity |
| --- | --- |
| Small Guppy | <p>Common</p> |
| Medium Guppy | <p>Common</p> |
| Large Guppy | <p>Common</p> |
| King Guppy | <p>Very Rare</p> |
| Carnivore | <p>Uncommon</p> |
| Ultravore | <p>Rare</p> |
| Starcatcher | <p>Uncommon</p> |
| Guppycruncher | <p>Uncommon</p> |
| Beetlemuncher | <p>Uncommon</p> |

</details>

<details>
<summary>List of aliens</summary>

| Name | Rarity |
| --- | --- |
| Mini Sylvester | <p>Common</p> |
| Sylvester | <p>Uncommon</p> |
| Balrog | <p>Very Rare</p> |
| Pointy Bilaterus | <p>Rare</p> |
| Round Bilaterus | <p>Rare</p> |
| Gus | <p>Very Rare</p> |
| Psychosquid | <p>Very Rare</p> |

</details>

<details>
<summary>SPOILERS!! List of special fish</summary>

| Name | Rarity |
| --- | --- |
| Santa | <p>Very Rare</p> |
| Rocky | <p>Very Rare</p> |
| Ludwig | <p>Very Rare</p> |
| Kilgore | <p>Extremely Rare!</p> |

</details>

### Credits
This mod was created by MonkeyMan1242 using [Hatchery](https://github.com/coolbot100s/Hatchery) v1.2.0